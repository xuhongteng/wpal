"""并发长连接压测：N 条 keep-alive 连接，每秒各发一次请求。"""
import asyncio
import json
import subprocess
import sys
import time

TARGETS = [
    ("Python(FastAPI 现版)", 8891, "/api/snapshot"),
    ("Go(标准库)", 9911, "/api/snapshot"),
    ("Rust(标准库)", 9912, "/api/snapshot"),
]


def rss_of(pattern):
    out = subprocess.run(
        ["ps", "-o", "rss=,args=", "-C", pattern], capture_output=True, text=True
    ).stdout.strip()
    if not out:
        return None
    return sum(int(l.split()[0]) for l in out.splitlines()) / 1024.0


async def hold(host, port, path, stop, counter):
    reader, writer = await asyncio.open_connection(host, port)
    try:
        while not stop.is_set():
            req = f"GET {path} HTTP/1.1\r\nHost: x\r\nConnection: keep-alive\r\n\r\n"
            writer.write(req.encode())
            await writer.drain()
            data = await asyncio.wait_for(reader.read(65536), timeout=5)
            counter["bytes"] += len(data)
            counter["reqs"] += 1
            await asyncio.sleep(1)
    except Exception:
        pass
    finally:
        try:
            writer.close()
        except Exception:
            pass


async def main(n=50, dur=20):
    for name, port, path in TARGETS:
        # 采样间隔：Go/Rust 是宿主进程，Python 在容器内
        pat = {"Python(FastAPI 现版)": "uvicorn", "Go(标准库)": "goserver",
               "Rust(标准库)": "rustserver"}[name]
        before = rss_of(pat)
        stop = asyncio.Event()
        counter = {"bytes": 0, "reqs": 0}
        tasks = [asyncio.create_task(hold("127.0.0.1", port, path, stop, counter))
                 for _ in range(n)]
        await asyncio.sleep(dur)
        stop.set()
        await asyncio.gather(*tasks, return_exceptions=True)
        after = rss_of(pat)
        print(json.dumps({
            "impl": name,
            "rss_idle_mib": round(before, 1) if before else None,
            "rss_under_%d_conns_mib" % n: round(after, 1) if after else None,
            "delta_mib": round(after - before, 2) if (before and after) else None,
            "reqs": counter["reqs"],
            "bytes_per_req": round(counter["bytes"] / max(1, counter["reqs"])),
        }, ensure_ascii=False))


asyncio.run(main())
