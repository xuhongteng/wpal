# 三语言体积基准（2026-10-24 实测）

方法：三个实现都读 /proc、都吐 JSON、都用 keep-alive 长连接，同一台机器同一时刻测。

| | Python(FastAPI 现版) | Go(标准库) | Rust(标准库) |
|---|---|---|---|
| 空闲 RSS | 45~105 MiB | 6.4~8.2 MiB | 2.2~2.6 MiB |
| 50 并发后 RSS 增量 | — | +4.68 MiB | +0.94 MiB |
| 50 并发吞吐 | 2.25 req/s（被采集拖死） | 50 req/s | 50 req/s |
| 单请求 p50 / p95 | 41.8 / 91.5 ms | 0.3 / 0.3 ms | 0.13 / 0.15 ms |
| 产物体积 | 237 MB（镜像） | 5.1 MB（静态单文件） | 0.4 MB（静态单文件） |

**口径说明**：Go/Rust 基准只采集 CPU/内存/负载，Python 版采集的是**全量快照**
（含约 240 个进程的遍历、磁盘 IO、网卡、TCP 状态），两者工作量不等，
延迟不能直接对比；内存与产物体积则是可比的。

Python 采集一次全量快照实测 p50 40.3ms → 每秒采一次 ≈ 占用 4% 单核。

## 复现

```bash
cd bench
export PATH=~/sdk/go/bin:$PATH        # Go SDK
export PATH=$HOME/.cargo/bin:$PATH     # Rust
cd go && go build -ldflags="-s -w" -o ../goserver . && cd ..
cd rust && cargo build --release && strip target/release/bench && cp target/release/bench ../rustserver && cd ..
bash run.sh
```
