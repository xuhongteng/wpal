#!/bin/bash
# 三语言一次性完整基准：启动 → 延迟 → 50 并发压测 → 收尾
set -u
cd /tmp/bench

./goserver > go.log 2>&1 &
GO_PID=$!
./rustserver > rust.log 2>&1 &
RU_PID=$!
sleep 2

echo "=== 启动即报的自身 RSS ==="
grep READY go.log rust.log

echo
echo "=== 单请求延迟（40 次，p50/p95/max）==="
python3 latency.py

echo
echo "=== 50 条并发长连接（20s，每连接每秒 1 次请求）==="
python3 load.py

echo
echo "=== 二进制 / 镜像体积 ==="
ls -l goserver rustserver | awk '{printf "%-12s %8.1f MB\n", $9, $5/1024/1024}'

echo
echo "=== Python 现版：采集一次全量快照的真实耗时 ==="
sudo -n docker exec monitor python3 -c "
import time, sys
sys.path.insert(0,'/app')
from app.collector import Collector
from app.config import settings
c = Collector(settings); c.sample()
ts=[]
for _ in range(20):
    t0=time.perf_counter(); c.sample(); ts.append((time.perf_counter()-t0)*1000)
ts.sort()
p50=ts[len(ts)//2]
print('  p50 %.1f ms | p95 %.1f ms | max %.1f ms' % (p50, ts[int(len(ts)*0.95)-1], ts[-1]))
print('  → 每秒采一次 ≈ 每秒占用 %.1f%% 单核' % (p50/10))
"

kill $GO_PID $RU_PID 2>/dev/null
wait 2>/dev/null
echo "done"
