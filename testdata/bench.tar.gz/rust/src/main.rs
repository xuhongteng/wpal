// 基准：Rust 版最小可用监控服务（仅标准库，无任何 crate）
use std::io::{Read, Write};
use std::net::TcpListener;

fn rss_mib() -> f64 {
    let s = std::fs::read_to_string("/proc/self/statm").unwrap_or_default();
    let pages: f64 = s.split_whitespace().nth(1).and_then(|x| x.parse().ok()).unwrap_or(0.0);
    pages * 4096.0 / 1024.0 / 1024.0
}

fn collect_json() -> String {
    let stat = std::fs::read_to_string("/proc/stat").unwrap_or_default();
    let mut busy = 0.0;
    for ln in stat.lines() {
        if ln.starts_with("cpu ") {
            let v: Vec<f64> = ln
                .split_whitespace()
                .skip(1)
                .filter_map(|x| x.parse().ok())
                .collect();
            if v.len() >= 8 {
                let (user, nice, sys, idle, iowait, steal) = (v[0], v[1], v[2], v[3], v[4], v[7]);
                let total = user + nice + sys + idle + iowait + steal;
                if total > 0.0 {
                    busy = 100.0 * (total - idle) / total;
                }
            }
            break;
        }
    }
    let mem = std::fs::read_to_string("/proc/meminfo").unwrap_or_default();
    let mut total_kb = 0.0f64;
    let mut avail_kb = 0.0f64;
    for ln in mem.lines() {
        if ln.starts_with("MemTotal:") {
            total_kb = ln.split_whitespace().nth(1).and_then(|x| x.parse().ok()).unwrap_or(0.0);
        }
        if ln.starts_with("MemAvailable:") {
            avail_kb = ln.split_whitespace().nth(1).and_then(|x| x.parse().ok()).unwrap_or(0.0);
        }
    }
    let pct = if total_kb > 0.0 { 100.0 * (total_kb - avail_kb) / total_kb } else { 0.0 };
    format!(
        "{{\"ts\":{},\"cpu\":{{\"total\":{:.2}}},\"mem\":{{\"total\":{},\"available\":{},\"percent\":{:.2}}}}}",
        std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_secs_f64(),
        busy,
        (total_kb * 1024.0) as u64,
        (avail_kb * 1024.0) as u64,
        pct
    )
}

fn main() {
    let listener = TcpListener::bind("127.0.0.1:9912").unwrap();
    println!("RUST_READY rss={:.1}MiB", rss_mib());
    for stream in listener.incoming() {
        // 每连接一线程：与 Go 的 goroutine 模型对齐，测并发下的真实内存
        std::thread::spawn(move || {
            let mut s = stream.unwrap();
            let mut buf = [0u8; 4096];
            loop {
                let n = match s.read(&mut buf) {
                    Ok(0) | Err(_) => break,
                    Ok(n) => n,
                };
                let body = collect_json();
                let resp = format!(
                    "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: keep-alive\r\n\r\n{}",
                    body.len(),
                    body
                );
                if s.write_all(resp.as_bytes()).is_err() {
                    break;
                }
                let _ = n;
            }
        });
    }
}
