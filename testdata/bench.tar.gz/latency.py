"""单请求延迟对比：同一时刻打满 CPU 的情况下，各实现的 /api/snapshot 响应时间。"""
import http.client
import json
import statistics
import time

TARGETS = [
    ("Python(FastAPI 现版)", 8891),
    ("Go(标准库)", 9911),
    ("Rust(标准库)", 9912),
]

N = 40
for name, port in TARGETS:
    lat = []
    try:
        c = http.client.HTTPConnection("127.0.0.1", port, timeout=30)
        for _ in range(N):
            t0 = time.perf_counter()
            c.request("GET", "/api/snapshot")
            r = c.getresponse()
            body = r.read()
            lat.append((time.perf_counter() - t0) * 1000)
        c.close()
        lat.sort()
        print(json.dumps({
            "impl": name,
            "p50_ms": round(statistics.median(lat), 1),
            "p95_ms": round(lat[int(len(lat) * 0.95) - 1], 1),
            "max_ms": round(lat[-1], 1),
            "resp_bytes": len(body),
        }, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"impl": name, "error": str(e)}, ensure_ascii=False))
