// 基准：Go 版最小可用监控服务（net/http + 直读 /proc，无第三方依赖）
package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"
)

func rssMiB() float64 {
	b, _ := os.ReadFile("/proc/self/statm")
	f := strings.Fields(string(b))
	if len(f) < 2 {
		return 0
	}
	pages, _ := strconv.ParseFloat(f[1], 64)
	return pages * 4096 / 1024 / 1024
}

func collect() map[string]any {
	out := map[string]any{"ts": float64(time.Now().UnixNano()) / 1e9}

	// /proc/stat 第一行：cpu 总量
	stat, _ := os.ReadFile("/proc/stat")
	lines := strings.Split(string(stat), "\n")
	for _, ln := range lines {
		if strings.HasPrefix(ln, "cpu ") {
			fs := strings.Fields(ln)[1:]
			var user, nice, sys, idle, iowait, steal float64
			vals := make([]float64, len(fs))
			for i, v := range fs {
				vals[i], _ = strconv.ParseFloat(v, 64)
			}
			if len(vals) >= 8 {
				user, nice, sys, idle, iowait = vals[0], vals[1], vals[2], vals[3], vals[4]
				steal = vals[7]
			}
			total := user + nice + sys + idle + iowait + steal
			busy := 0.0
			if total > 0 {
				busy = 100 * (total - idle) / total
			}
			out["cpu"] = map[string]any{
				"total": busy,
				"breakdown": map[string]any{
					"user": user, "system": sys, "iowait": iowait, "steal": steal,
				},
			}
			break
		}
	}

	// /proc/meminfo
	mem, _ := os.ReadFile("/proc/meminfo")
	var totalKB, availKB float64
	for _, ln := range strings.Split(string(mem), "\n") {
		if strings.HasPrefix(ln, "MemTotal:") {
			totalKB, _ = strconv.ParseFloat(strings.Fields(ln)[1], 64)
		}
		if strings.HasPrefix(ln, "MemAvailable:") {
			availKB, _ = strconv.ParseFloat(strings.Fields(ln)[1], 64)
		}
	}
	if totalKB > 0 {
		out["mem"] = map[string]any{
			"total": totalKB * 1024,
			"available": availKB * 1024,
			"percent": 100 * (totalKB - availKB) / totalKB,
		}
	}

	load, _ := os.ReadFile("/proc/loadavg")
	out["load"] = strings.Fields(string(load))
	out["host"] = map[string]any{"hostname": "bench"}
	return out
}

func main() {
	mux := http.NewServeMux()
	mux.HandleFunc("/api/snapshot", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(collect())
	})
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		io.WriteString(w, "ok")
	})
	fmt.Printf("GO_READY rss=%.1fMiB\n", rssMiB())
	srv := &http.Server{Addr: "127.0.0.1:9911", Handler: mux}
	srv.ListenAndServe()
}
